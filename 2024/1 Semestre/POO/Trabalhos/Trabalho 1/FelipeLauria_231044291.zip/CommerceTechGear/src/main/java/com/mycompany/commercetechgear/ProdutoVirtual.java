package com.mycompany.commercetechgear;

/**
 * Representa um produto virtual na loja.
 */
public class ProdutoVirtual extends Produto {
    private double tamanhoArquivo;
    private String formatoArquivo;

    /**
     * Constrói um novo produto virtual.
     * 
     * @param id o ID do produto
     * @param nome o nome do produto
     * @param preco o preço do produto
     * @param descricao a descrição do produto
     * @param marca a marca do produto
     * @param categoria a categoria do produto
     * @param tamanhoArquivo o tamanho do arquivo virtual
     * @param formatoArquivo o formato do arquivo virtual
     * @param categoriaa a categoria à qual o produto pertence
     */
    public ProdutoVirtual(int id, String nome, double preco, String descricao, String marca, int categoria, double tamanhoArquivo, String formatoArquivo, Categoria categoriaa) {
        super(id, nome, preco, descricao, marca, categoria, categoriaa);
        this.tamanhoArquivo = tamanhoArquivo;
        this.formatoArquivo = formatoArquivo;
    }

    /**
     * Obtém o tamanho do arquivo virtual.
     * 
     * @return o tamanho do arquivo
     */
    public double getTamanhoArquivo() {
        return tamanhoArquivo;
    }

    /**
     * Obtém o formato do arquivo virtual.
     * 
     * @return o formato do arquivo
     */
    public String getFormatoArquivo() {
        return formatoArquivo;
    }
    
    /**
     * Realiza o download do produto virtual.
     * 
     * @param itens o número de itens para download
     */
    public void realizarDownload(int itens) {
        if (itens != 0) {
            System.out.println("Realizando download de: " + itens + " item(ns)!");
            System.out.println("Baixando...");
            System.out.println("");
            System.out.println("Download finalizado com sucesso!");
        } else {
            System.out.println("Impossível realizar download");
        }
    }
}