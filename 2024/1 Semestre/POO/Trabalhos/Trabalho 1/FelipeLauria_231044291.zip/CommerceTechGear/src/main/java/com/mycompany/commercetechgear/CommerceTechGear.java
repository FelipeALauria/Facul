/**
 * Classe principal que inicializa a aplicação CommerceTechGear.
 * 
 * Esta classe faz a leitura de arquivos de categorias, produtos físicos e produtos virtuais,
 * instanciando os objetos correspondentes e exibindo uma interface de usuário.
 * 
 * @author Felipe Lauria
 */

package com.mycompany.commercetechgear;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CommerceTechGear {

    /**
     * Método principal que inicia a aplicação CommerceTechGear.
     * 
     * Este método realiza a leitura de arquivos de categorias, produtos físicos e produtos virtuais,
     * instanciando os objetos correspondentes e exibindo uma interface de usuário.
     * 
     * @param args argumentos da linha de comando (não utilizados)
     * @throws IOException se ocorrer um erro de entrada/saída durante a leitura dos arquivos
     */
    public static void main(String[] args) throws IOException {
        
        // Instanciando uma nova categoria
        Categoria categoriaa = new Categoria(12, "aa", "aa");
        // Instanciando uma nova loja
        Loja loja = new Loja("Commerce TechGear", "47.960.950/0001-21", "Rua General Glicério", 2746, "18133-365", categoriaa);
        // Instanciando um novo DisplayLoja
        DisplayLoja dl = new DisplayLoja(loja, categoriaa);
        
        // Definindo os arquivos de entrada
        File arquivo1 = new File("C:\\Users\\felip\\OneDrive\\Pictures\\Documents\\NetBeansProjects\\CommerceTechGear\\src\\main\\java\\com\\mycompany\\commercetechgear\\categorias.txt");
        File arquivo2 = new File("C:\\Users\\felip\\OneDrive\\Pictures\\Documents\\NetBeansProjects\\CommerceTechGear\\src\\main\\java\\com\\mycompany\\commercetechgear\\produtoFisico.txt");
        File arquivo3 = new File("C:\\Users\\felip\\OneDrive\\Pictures\\Documents\\NetBeansProjects\\CommerceTechGear\\src\\main\\java\\com\\mycompany\\commercetechgear\\produtoVirtual.txt");
        
        Scanner sc = new Scanner(System.in);
        
        // Leitura do arquivo1 (categorias.txt)
        try {
            sc = new Scanner(arquivo1);
        } catch (FileNotFoundException exception) {
            Logger.getLogger(DisplayLoja.class.getName()).log(Level.SEVERE, null, exception);
        }
        
        // Ignora a primeira linha do arquivo
        sc.nextLine();
        // Loop para processar cada linha do arquivo
        while (sc.hasNextLine()) {
            String linha = sc.nextLine();
            String[] campos = linha.split("#");
            int cod = 0;
            String na = "a";
            String de = "a";
            if (campos.length == 3) {
                int codigo = Integer.parseInt(campos[0]);
                String nome = campos[1];
                String descricao = campos[2];
                cod = codigo;
                na = nome;
                de = descricao;
            }
            // Constrói a categoria com base nos dados do arquivo
            loja.construtorCategoria(cod, na, de);
        }
        
        // Leitura do arquivo2 (produtoFisico.txt)
        try {
            sc = new Scanner(arquivo2);
        } catch (FileNotFoundException exception) {
            Logger.getLogger(DisplayLoja.class.getName()).log(Level.SEVERE, null, exception);
        }
        
        // Ignora a primeira linha do arquivo
        sc.nextLine();
        // Loop para processar cada linha do arquivo
        while (sc.hasNextLine()) {
            String linha = sc.nextLine();
            String[] campos = linha.split("#");
            int identification = 0;
            String name = "a";
            double price = 0;
            String description = "a";
            String brand = "a";
            int categorie = 0;
            double weigth = 0;
            String size = "a";
            if (campos.length == 8) {
                int id = Integer.parseInt(campos[0]);
                String nome = campos[1];
                double preco = Double.parseDouble(campos[2]);
                String descricao = campos[3];
                String marca = campos[4];
                int categoria = Integer.parseInt(campos[5]);
                double peso = Double.parseDouble(campos[6]);
                String dimensoes = campos[7];
                
                identification = id;
                name = nome;
                price = preco;
                description = descricao;
                brand = marca;
                categorie = categoria;
                weigth = peso;
                size = dimensoes;
            }
            // Constrói o produto físico com base nos dados do arquivo
            categoriaa.construtorProdutoFisico(identification, name, price, description, brand, categorie, weigth, size, categoriaa);
        }
        
        // Leitura do arquivo3 (produtoVirtual.txt)
        try {
            sc = new Scanner(arquivo3);
        } catch (FileNotFoundException exception) {
            Logger.getLogger(DisplayLoja.class.getName()).log(Level.SEVERE, null, exception);
        }
        
        // Ignora a primeira linha do arquivo
        sc.nextLine();
        // Loop para processar cada linha do arquivo
        while (sc.hasNextLine()) {
            String linha = sc.nextLine();
            String[] campos = linha.split("#");
            int identification = 0;
            String name = "a";
            double price = 0;
            String description = "a";
            String brand = "a";
            int categorie = 0;
            double fileSize = 0;
            String fileType = "a";
            if (campos.length == 8) {
                int id = Integer.parseInt(campos[0]);
                String nome = campos[1];
                double preco = Double.parseDouble(campos[2]);
                String descricao = campos[3];
                String marca = campos[4];
                int categoria = Integer.parseInt(campos[5]);
                String[] formatoCampos = campos[6].split(" ");
                double tamanhoArquivo = Double.parseDouble(formatoCampos[0]);
                String tipoArquivo = campos[7];
                
                identification = id;
                name = nome;
                price = preco;
                description = descricao;
                brand = marca;
                categorie = categoria;
                fileSize = tamanhoArquivo;
                fileType = tipoArquivo;
            }
            // Constrói o produto virtual com base nos dados do arquivo
            categoriaa.construtorProdutoVirtual(identification, name, price, description, brand, categorie, fileSize, fileType, categoriaa);
        }
        
        // Exibe a interface do usuário
        dl.interfaceUsuario();       
    }    
}