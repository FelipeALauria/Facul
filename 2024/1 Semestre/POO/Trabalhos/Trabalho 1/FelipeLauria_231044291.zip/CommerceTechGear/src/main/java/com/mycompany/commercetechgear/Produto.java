package com.mycompany.commercetechgear;

import java.util.Scanner;

/**
 * Representa um produto abstrato na loja.
 */
public abstract class Produto {
    private String nome;
    private int id;
    private double preco;
    private String descricao;
    private String marca;
    private int categoria;
    private Categoria categoriaa;
    private int quantidadeCarrinho = 0;
    private int quantidadeEstoque = 1;
    private double valorTotal = preco;
    
    Scanner sc = new Scanner(System.in);

    /**
     * Constrói um novo produto.
     * 
     * @param id o ID do produto
     * @param nome o nome do produto
     * @param preco o preço do produto
     * @param descricao a descrição do produto
     * @param marca a marca do produto
     * @param categoria a categoria do produto
     * @param categoriaa a categoria à qual o produto pertence
     */
    public Produto(int id, String nome, double preco, String descricao, String marca, int categoria, Categoria categoriaa) {
        this.nome = nome;
        this.id = id;
        this.preco = preco;
        this.descricao = descricao;
        this.marca = marca;
        this.categoria = categoria;
        this.categoriaa = categoriaa;
    }
        
        /**
      * Obtém o nome do produto.
      * 
      * @return o nome do produto
      */
     public String getNome() {
         return nome;
     }

     /**
      * Obtém o ID do produto.
      * 
      * @return o ID do produto
      */
     public int getId() {
         return id;
     }

     /**
      * Obtém o preço do produto.
      * 
      * @return o preço do produto
      */
     public double getPreco() {
         return preco;
     }

     /**
      * Obtém a descrição do produto.
      * 
      * @return a descrição do produto
      */
     public String getDescricao() {
         return descricao;
     }

     /**
      * Obtém a marca do produto.
      * 
      * @return a marca do produto
      */
     public String getMarca() {
         return marca;
     }

     /**
      * Obtém a categoria do produto.
      * 
      * @return a categoria do produto
      */
     public int getCategoria() {
         return categoria;
     }

     /**
      * Obtém a quantidade de unidades do produto no carrinho.
      * 
      * @return a quantidade de unidades do produto no carrinho
      */
     public int getQuantidadeCarrinho() {
         return quantidadeCarrinho;
     }

     /**
      * Obtém o valor total do produto.
      * 
      * @return o valor total do produto
      */
     public double getValorTotal() {
         return valorTotal;
     }

     /**
      * Obtém a quantidade de unidades disponíveis em estoque do produto.
      * 
      * @return a quantidade de unidades disponíveis em estoque do produto
      */
     public int getQuantidadeEstoque() {
         return quantidadeEstoque;
     }

     /**
      * Define o preço do produto.
      * 
      * @param preco o novo preço do produto
      */
     public void setPreco(double preco) {
         this.preco = preco;
     }

     /**
      * Define a quantidade de unidades disponíveis em estoque do produto.
      * 
      * @param quantidadeEstoque a nova quantidade de unidades disponíveis em estoque do produto
      */
     public void setQuantidadeEstoque(int quantidadeEstoque) {
         this.quantidadeEstoque += quantidadeEstoque;
     }

     /**
      * Define a quantidade de unidades do produto no carrinho.
      * 
      * @param quantidadeCarrinho a nova quantidade de unidades do produto no carrinho
      */
     public void setQuantidadeCarrinho(int quantidadeCarrinho) {
         this.quantidadeCarrinho = quantidadeCarrinho;
     }

     /**
      * Define o valor total do produto.
      */
     public void setValorTotal() {
         this.valorTotal = (preco * quantidadeCarrinho);
     }
    
    /**
     * Atualiza o estoque do produto.
     */
    public void atualizarEstoque() {
        System.out.println("A quantidade do produto" + getNome() + " é de: " + getQuantidadeEstoque() + "!"
                + "\nInsera um número negativo para subtrair do estoque ou um número positivo para aumentar o estoque!");
        int controle = sc.nextInt();
        
        setQuantidadeEstoque(controle);
        
        System.out.println("Estoque atualizado com sucesso!"
                + "\nQuantidade atul do produto " + getNome() + " é de " + getQuantidadeEstoque() + "!\n\n");
    }
    
    /**
     * Atualiza o preço do produto.
     */
    public void atualizarPreco() {
        System.out.println("O preço atual é de " + getPreco() + " reais!"
                 + "\nInforme o novo valor");
         double novoPreco = sc.nextDouble();
         
         setPreco(novoPreco);
         
         System.out.println("Valor atualizado com sucesso!"
                 + "\nNovo valor de " + getPreco() + " reais!");
     }
}
