package com.mycompany.commercetechgear;

import java.util.Scanner;

/**
 * Representa um display para a interface da loja.
 */
public class DisplayLoja {
   private Loja loja;
   private Categoria categoriaa;

   Scanner sc = new Scanner(System.in);

    /**
     * Constrói um novo display para a interface da loja.
     * 
     * @param loja a loja associada ao display
     * @param categoria a categoria associada ao display
     */
    public DisplayLoja(Loja loja, Categoria categoria) {
        this.loja = loja;
        this.categoriaa = categoria;
    }
   
   /**
    * Exibe a interface do usuário.
    */
   public void interfaceUsuario() {
       int controle = 8;
       while (controle != 0) {
           System.out.println("Bem-vindo ao sistema da " + loja.getNome() + ", o que você deseja fazer: "
                   + "\n1- Buscar produto;"
                   + "\n2- Buscar categoria;"
                   + "\n3- Adicionar produto ao carrinho;"
                   + "\n4- Finalizar a compra;"
                   + "\n5- Gerenciar categorias;"
                   + "\n6- Gerenciar produtos;"
                   + "\n7- Informações da loja"
                   + "\n0- Fechar o sistema\n.");
           controle = sc.nextInt();
           
           switch (controle) {
               case 1 -> buscarProduto();
               case 2 -> buscarCategoria();
               case 3 -> adicionarAoCarrinho();
               case 4 -> realizarCompra();
               case 5 -> gerenciarCategorias();
               case 6 -> gerenciarProdutos();
               case 7 -> informacoes();
               case 0 -> System.out.println("\nFechando...\n\n\n");
               default -> System.out.println("\nComando errado!\n\n\n");
           }
       }
   }
   
   /**
    * Busca um produto pelo ID.
    */
   private void buscarProduto()  {
       System.out.println("\n\nDigite o ID do produto:\n ");
       int id = sc.nextInt();
                   
       Produto produto = loja.buscarProduto(id);
       if(produto instanceof ProdutoFisico)
            System.out.println(produto.getId() +"#" + produto.getNome() +"#" + produto.getPreco() +"#" + produto.getDescricao() +"#" + produto.getMarca() +"#" + ((ProdutoFisico) produto).getPeso() +"#" + ((ProdutoFisico) produto).getDimensoes());
       else
           System.out.println(produto.getId() + "#" + produto.getNome() + "#" + produto.getPreco() + "#" + produto.getDescricao() + "#" + produto.getMarca() + "#" + ((ProdutoVirtual) produto).getTamanhoArquivo() + "#" + ((ProdutoVirtual) produto).getFormatoArquivo());
   }
   
   /**
    * Busca uma categoria pelo código.
    */
    private void  buscarCategoria()  {
        System.out.println("\n\nDigite o código da categoria desejada: \n");
        int codigo = sc.nextInt();
        
        Categoria categoria = loja.buscarCategoria(codigo);
        System.out.println(categoria.getCodigo() + "#" + categoria.getNome() + "#" + categoria.getDescricao());
    }
   
   /**
    * Adiciona um produto ao carrinho.
    */
   private void adicionarAoCarrinho() {
       System.out.println("\n\nDigite o ID do produto que deseja adicionar ao carrinho: \n");
       int id = sc.nextInt();
       
       loja.adicionarAoCarrinho(id);
   }
   
   /**
    * Finaliza a compra.
    */
   private void realizarCompra() {
       loja.finalizarCompra();
   }
   
   /**
    * Gerencia as categorias.
    */
   private void gerenciarCategorias()  {
       int controle = 4;
       while (controle != 0) {
            System.out.println("""
                               
                               
                               Qual ação você deseja realizar: 
                               1- Adicionar categoria;
                               2- Remover categoria;
                               3- Mostrar categorias;
                               0- Sair.
                               """);
            controle = sc.nextInt();   
            
            switch (controle) {
                case 1 -> loja.adicionarCategoria();
                case 2 -> loja.removerCategoria();
                case 3 -> loja.listaCategoria();
                case 0 -> System.out.println("\nFechando...\n\n\n");
                default -> System.out.println("\nComando errado!\n\n\n");              
            }
       }
   }
   
   /**
    * Gerencia os produtos.
    */
   private void gerenciarProdutos() {
       int controle = 8;
       while (controle != 0) {
            System.out.println("""
                               
                               Qual ação você deseja realizar: 
                               1- Adicionar produto;
                               2- Remover produto;
                               3- Gerenciar estoque;
                               4- Atualizar preço;
                               5- Mostrar produtos da loja;
                               0- Sair.
                               """);
            controle = sc.nextInt();   
            
           switch (controle) {
               case 1 -> loja.adicionarProduto();
               case 2 -> loja.removerProduto();
               case 3 -> loja.gerenciarEstoque();
               case 4 -> loja.atualizarPreco();
               case 5 -> loja.listaProdutos();
               case 0 -> System.out.println("\nFechando...\n\n\n");
               default -> System.out.println("\nComando errado!\n\n\n");
           }
       }

 
    }

    /**
     * Exibe as informações da loja.
     */
    private void informacoes() {
      loja.getInformacoes();  
    }
}