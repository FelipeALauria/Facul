package com.mycompany.commercetechgear;

import java.util.*;

/**
 * Representa uma loja que vende produtos e oferece várias funcionalidades relacionadas ao gerenciamento de produtos e categorias.
 * Permite adicionar, remover e gerenciar produtos e categorias, além de realizar compras e exibir informações da loja.
 */
public class Loja {
    private final String nome;
    private final String cnpj;
    private final String endereco;
    private final String cep;
    private final int numeroEndereco;
    private final Categoria categoriaaa;
    public List<Categoria> listaCategorias = new ArrayList<>();
    public List<Produto> carrinho = new ArrayList<>();       
    
    Scanner sc = new Scanner(System.in);
    
    /**
     * Cria uma nova instância de Loja com os detalhes fornecidos.
     * 
     * @param nome o nome da loja
     * @param cnpj o CNPJ da loja
     * @param endereco o endereço da loja
     * @param numeroEndereco o número do endereço da loja
     * @param cep o CEP da loja
     * @param categoria a categoria principal da loja
     */
    public Loja(String nome, String cnpj, String endereco, int numeroEndereco, String cep, Categoria categoria) {
        this.nome = nome;
        this.cnpj = cnpj;
        this.endereco = endereco;
        this.numeroEndereco = numeroEndereco;
        this.cep = cep;
        this.categoriaaa = categoria;
    }
    
    /**
     * Obtém o nome da loja.
     * 
     * @return o nome da loja
     */
    public String getNome() {
        return nome;
    }

    /**
     * Obtém o CNPJ da loja.
     * 
     * @return o CNPJ da loja
     */
    public String getCnpj() {
        return cnpj;
    }

    /**
     * Obtém o endereço da loja.
     * 
     * @return o endereço da loja
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * Obtém o CEP da loja.
     * 
     * @return o CEP da loja
     */
    public String getCep() {
        return cep;
    }

    /**
     * Obtém o número do endereço da loja.
     * 
     * @return o número do endereço da loja
     */
    public int getNumeroEndereco() {
        return numeroEndereco;
    }
    
    /**
     * Exibe as informações da loja, incluindo nome, endereço, número, CEP e CNPJ.
     */
   public void getInformacoes() {
       System.out.println(("A loja " + nome + "fica localizada no endereço: " + endereco + " \tnúmero: " + numeroEndereco + "\tCEP: " + cep + "\nCNPJ é: " + cnpj + "!\n\n\n\n"));
   }
   
   /**
    * Adiciona uma nova categoria à loja com o código, nome e descrição fornecidos pelo usuário.
    */
   public void adicionarCategoria(){
       System.out.println("Digite o código:\n");
       int codigo = sc.nextInt();
       sc.nextLine();
       System.out.println("Digite o nome:\n");
       String nome = sc.nextLine();
       System.out.println("Digite a descrição:\n");
       String descricao = sc.nextLine();
      
       Categoria novaCategorias = new Categoria(codigo, nome, descricao);
       listaCategorias.add(novaCategorias);
        System.out.println("Categoria adicioada com sucesso!");
      
    } 
   
   /**
    * Remove uma categoria da loja com base no código fornecido pelo usuário.
    */
   public void removerCategoria() {
       System.out.println("Digite o código da categoria que deseja remover: ");
       int codigo = sc.nextInt();

       for (Categoria categoria : listaCategorias) {
           if (categoria.getCodigo() == codigo) {
               listaCategorias.remove(categoria);
           }
           else{
               System.out.println("Categoria não existente ou já removida!");
               break;
            }
         }                  
       System.out.println("Categoria removida com sucesso!");
    }
   
   /**
    * Busca uma categoria na loja com base no código fornecido.
    * 
    * @param codigo o código da categoria a ser buscada
    * @return a categoria encontrada ou null se não encontrada
    */
   public Categoria buscarCategoria(int codigo) {
        for (Categoria categoria : listaCategorias) {
            if (categoria.getCodigo() == codigo) {
                return categoria;
            }
        }

        System.out.println("Categoria não identificada!\nDeseja adicioná-la?\n1- Sim\n2- Não");
        int controle = sc.nextInt();
        if (controle == 1) {
            adicionarCategoria();
            return buscarCategoria(codigo);
        } else {
            Categoria categoriaNaoAdicionada = new Categoria(0, "Categoria não adicionada", " ");
            return categoriaNaoAdicionada;
        }
}
       
   /**
    * Adiciona um novo produto à loja com base na categoria fornecida.
    */
   public void adicionarProduto()  {
        System.out.println("Insira o código da categoria do produto a ser adicionado: \n");
        int codigo = sc.nextInt();
        for (Categoria categoria : listaCategorias) {
            if (categoria.getCodigo() == codigo)     
                 categoria.adicionarProduto(categoriaaa);
            else {
                System.out.println("Categoria não existente!)"
                        + "\nDeseja adiciona-lá:"
                        + "\n1- Sim;"
                        + "\n2- Não.");
                int controle = sc.nextInt();
                
                if (controle == 1) {
                    adicionarCategoria();
                    adicionarProduto();
                }
                else 
                    break;
            }
       }
   }
         
   /**
    * Remove um produto da loja com base na categoria fornecida.
    */
   public void removerProduto() {
       System.out.println("Insira o código da categoria do produto a ser removido: \n");
        int codigo = sc.nextInt();
        for (Categoria categoria : listaCategorias) {
            if (categoria.getCodigo() == codigo)     
                 categoria.removerProduto(categoriaaa);
            else 
                 System.out.println("Categoria não existente!");
        }
  }
  
   /**
    * Busca um produto na loja com base no ID fornecido.
    * 
    * @param id o ID do produto a ser buscado
    * @return o produto encontrado ou null se não encontrado
    */
   public Produto buscarProduto(int id) {
           Produto produtoEncontrado = categoriaaa.buscarProduto(categoriaaa, id);
            return produtoEncontrado;
}

   /**
    * Adiciona uma quantidade especificada de um produto ao carrinho de compras.
    * 
    * @param id o ID do produto a ser adicionado ao carrinho
    */
   public void adicionarAoCarrinho(int id) {
        Produto produto = buscarProduto(id);
        System.out.println("Quantas quntidades do produto " + produto.getNome() + " deseja adicionar ao carrinho?\n");
        int quantidade = sc.nextInt();
        
       produto.setQuantidadeCarrinho(quantidade);
       produto.setValorTotal();
        
        carrinho.add(produto);
    }

   /**
    * Finaliza a compra, calculando o frete e/ou fazendo download dos produtos virtuais no carrinho.
    */
   public void finalizarCompra() {
    int controle = 0;
    int aux1 = 0;
    int aux2 = 0;
    int frete = 0;
    int download = 0;
    if (!carrinho.isEmpty()) {
        Produto produto = null;
        System.out.println("O carrinho tem os seguintes itens e quantidades:");
        for (Produto compra : carrinho) {
            System.out.println(compra.getNome() + "\t" + compra.getQuantidadeCarrinho());
            produto = compra;
        }
        
        System.out.println("E o valor total é de " + produto.getValorTotal() + " reais");
    } else {
        System.out.println("Carrinho vazio!\n\n");
        controle = 1;
    }
    
    if (controle == 0) {
        for (Produto produto : carrinho) {
            if (produto instanceof ProdutoFisico) {
                frete += produto.getQuantidadeCarrinho();                
            }    
            else {
                download += produto.getQuantidadeCarrinho();                
            }
        }
        for (Produto produto : carrinho) {
            if(produto instanceof ProdutoFisico){
                    ProdutoFisico produtoFisico = (ProdutoFisico) carrinho;
                    produtoFisico.calcularFretei(frete);
            }
            else {
                ProdutoVirtual produtoVirtual = (ProdutoVirtual) carrinho;
                produtoVirtual.realizarDownload(download);
            }
        }
    }
}

   /**
    * Permite ao usuário gerenciar o estoque de produtos de uma determinada categoria.
    */
   public void gerenciarEstoque() {
         categoriaaa.gerenciarEstoque(categoriaaa);
    }
    
   /**
    * Permite ao usuário atualizar o preço de produtos de uma determinada categoria.
    */
   public void atualizarPreco()  {
        categoriaaa.atualizarPreco(categoriaaa);
    } 
   
   /**
    * Constrói uma nova instância de Categoria e a adiciona à lista de categorias da loja.
    * 
    * @param code o código da categoria
    * @param name o nome da categoria
    * @param description a descrição da categoria
    */
   public void construtorCategoria(int code, String name, String description) {
       Categoria categoria = new Categoria (code, name, description);
       listaCategorias.add(categoria);
   }
   
   /**
    * Exibe uma lista das categorias disponíveis na loja.
    */
   public void listaCategoria() {
        Categoria categoriaa;
       for (Categoria categoria: listaCategorias) {
           categoriaa = categoria;
           System.out.println(categoriaa.getCodigo() + "#"  + categoriaa.getNome() + "#" +  categoriaa.getDescricao());
       }
   }
   
   /**
    * Exibe uma lista dos produtos disponíveis na loja.
    */
   public void listaProdutos() {
       categoriaaa.listaProdutos();
   }
}