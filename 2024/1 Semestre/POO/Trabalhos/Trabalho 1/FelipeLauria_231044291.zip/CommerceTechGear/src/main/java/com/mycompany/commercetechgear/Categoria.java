package com.mycompany.commercetechgear;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Representa uma categoria de produtos.
 */
public class Categoria {
    private int codigo;
    private String nome;
    private String descricao;
    public List<Produto> listaProdutos = new ArrayList<>();
    
    Scanner sc = new Scanner(System.in);

    /**
     * Constrói uma nova categoria com o código, nome e descrição fornecidos.
     * 
     * @param codigo o código da categoria
     * @param nome o nome da categoria
     * @param descricao a descrição da categoria
     */
    public Categoria(int codigo, String nome, String descricao) {
        this.codigo = codigo;
        this.nome = nome;
        this.descricao = descricao;
    }
        
    /**
     * Obtém o código da categoria.
     * 
     * @return o código da categoria
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * Obtém o nome da categoria.
     * 
     * @return o nome da categoria
     */
    public String getNome() {
        return nome;
    }

    /**
     * Obtém a descrição da categoria.
     * 
     * @return a descrição da categoria
     */
    public String getDescricao() {
        return descricao;
    }  
    
    /**
     * Adiciona um produto à categoria.
     * 
     * @param categoriaa a categoria do produto
     */
    public void adicionarProduto(Categoria categoriaa) {
        System.out.println("""
                           O produto que deseja adicionar é físico ou virtual:
                           1- Físico;
                           2- Virtual.""");
        int controle = sc.nextInt();
        
        if (controle == 1) {
            System.out.println("Digite o id:\n");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.println("Digite o nome:\n");
            String nome = sc.nextLine();
            System.out.println("Digite o preço:\n");
            double preco = sc.nextDouble();
            sc.nextLine();
            System.out.println("Digite a descrição:\n");
            String descricao = sc.nextLine();
            System.out.println("Digite a marca:\n");
            String marca = sc.nextLine();
            System.out.println("Digite a categoria:\n");
            int categoria = sc.nextInt();
            System.out.println("Digite o peso:\n");
            double peso = sc.nextDouble();
            sc.nextLine();
             System.out.println("Digite as dimensoes:\n");
             String dimensoes = sc.nextLine();
                                     
                Produto produto = new ProdutoFisico(id, nome, preco, descricao, marca, categoria, peso, dimensoes, categoriaa);
                listaProdutos.add(produto);
                System.out.println("Produto adicioado com sucesso!");
        }
           else {
            System.out.println("Digite o id:\n");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.println("Digite o nome:\n");
            String nome = sc.nextLine();
            System.out.println("Digite o preço:\n");
            double preco = sc.nextDouble();
            sc.nextLine();
            System.out.println("Digite a descrição:\n");
            String descricao = sc.nextLine();
            System.out.println("Digite a marca:\n");
            String marca = sc.nextLine();
            System.out.println("Digite a categoria:\n");
            int categoria = sc.nextInt();
            System.out.println("Digite o tamanho do arquivo:\n");
            double tamanhoArquivo = sc.nextDouble();
            sc.nextLine();
             System.out.println("Digite o formato do arquivo:\n");
             String formatoArquivo = sc.nextLine();
            
           
                
                Produto produto = new ProdutoVirtual(id, nome, preco, descricao, marca, categoria, tamanhoArquivo, formatoArquivo, categoriaa);
                listaProdutos.add(produto);
                System.out.println("Produto adicioado com sucesso!");
            }
    }
    
    /**
     * Remove um produto da categoria.
     * 
     * @param categoriaa a categoria do produto
     */
    public void removerProduto(Categoria categoriaa){
        System.out.println("Digite a id do produto a ser removido:\n ");
        int id = sc.nextInt();
        sc.nextLine();
        
        Produto produto = buscarProduto(categoriaa, id);
        
        if (produto == null) {
            System.out.println("Produto não existe ou já foi removido!");
            return;
        }  
        
        if (produto instanceof ProdutoFisico) {
            for (Produto produtosRemover : listaProdutos) {
                if (produtosRemover.getId() == id) {
                    listaProdutos.remove(produtosRemover);
                }
                else {
                    System.out.println("Produto não existente ou já removido!");
                    break;
                    }
               }
              System.out.println("Produto removido com sucesso!");
         }     
        else {
            for (Produto produtosRemover : listaProdutos) {
                if (produtosRemover.getId() == id) {
                    listaProdutos.remove(produtosRemover);
                }
                else {
                    System.out.println("Produto não existente ou já removido!");
                    break;
                    }
                }
         System.out.println("Produto removido com sucesso!");
        }
    }
    
    /**
     * Busca um produto na categoria pelo ID.
     * 
     * @param categoriaa a categoria do produto
     *

 @param id o ID do produto
     * @return o produto encontrado ou null se não encontrado
     */
        public Produto buscarProduto(Categoria categoriaa, int id) {
            for (Produto produto : listaProdutos) {
                if (produto.getId() == id) {
                    return produto;
                }
            }

            System.out.println("Produto não localizado ou não existente!\nDeseja adicioná-lo?\n1- Sim\n2- Não");
            int controle = sc.nextInt();
            if (controle == 1) {
                adicionarProduto(categoriaa);
                return buscarProduto(categoriaa, id);
            } else {
                Produto produtoNaoAdicionado = new ProdutoFisico(0, "Produto não adicionado", 0, " ", " ", 0, 0, " ", categoriaa);
                return produtoNaoAdicionado;
            }
        }

    
    /**
     * Gerencia o estoque de um produto na categoria.
     * 
     * @param categoriaa a categoria do produto
     */
    public void gerenciarEstoque(Categoria categoriaa) {
        System.out.println("Digite o id do produto que deseja gerenciar o estoque:\n");
        int id = sc.nextInt();
        
        for (Produto produto : listaProdutos) {
            if (produto.getId() == id)
                produto.atualizarEstoque();
            else {
                System.out.println("Produto não encotrado!"
                        + "\nDeseja adiciona-lo?"
                        + "\n1- Sim;"
                        + "\n2- Não.");
                int controle = sc.nextInt();
                
                if (controle == 1) {
                    adicionarProduto(categoriaa);
                    gerenciarEstoque(categoriaa);
                }
                else 
                    break;
            }
        }
    }

    /**
     * Atualiza o preço de um produto na categoria.
     * 
     * @param categoriaa a categoria do produto
     */
     public void atualizarPreco(Categoria categoriaa) {
         System.out.println("Digite o id do produto:\n");
         int id = sc.nextInt();
         
         for (Produto produto : listaProdutos) {
             if (produto.getId() == id)
                 produto.atualizarPreco();
         }
     }
     
    /**
     * Lista os produtos da categoria.
     */
      public void listaProdutos() {
       for (Produto produto : listaProdutos) {
           if (produto instanceof ProdutoFisico)
               System.out.println(produto.getId() + "#" + produto.getNome() + "#" + produto.getPreco() + "#" + produto.getDescricao() + "#" + produto.getMarca() + "#" + produto.getCategoria() + "#" + ((ProdutoFisico) produto).getPeso() + "#" + ((ProdutoFisico) produto).getDimensoes());
           else
                System.out.println(produto.getId() + "#" + produto.getNome() + "#" + produto.getPreco() + "#" + produto.getDescricao() + "#" + produto.getMarca() + "#" + produto.getCategoria() + "#" + ((ProdutoVirtual) produto).getTamanhoArquivo()+ "#" + ((ProdutoVirtual) produto).getFormatoArquivo());
       }   
   }
     
    /**
     * Constrói um produto físico e o adiciona à categoria.
     * 
     * @param identification o ID do produto
     * @param name o nome do produto
     * @param value o preço do produto
     * @param description a descrição do produto
     * @param brand a marca do produto
     * @param categorie a categoria do produto
     * @param weight o peso do produto físico
     * @param size as dimensões do produto físico
     * @param categoriee a categoria do produto
     */
     public void construtorProdutoFisico(int identification, String name, double value, String description, String brand, int categorie, double weight, String size, Categoria categoriee) {
        Produto produto = new ProdutoFisico(identification, name, value, description, brand, categorie, weight, size, categoriee);
        listaProdutos.add(produto);
    }
    
    /**
     * Constrói um produto virtual e o adiciona à categoria.
     * 
     * @param identification o ID do produto
     * @param name o nome do produto
     * @param value o preço do produto
     * @param description a descrição do produto
     * @param brand a marca do produto
     * @param categorie a categoria do produto
     * @param fileSize o tamanho do arquivo do produto virtual
     * @param fileType o formato do arquivo do produto virtual
     * @param categoriee a categoria do produto
     */
    public void construtorProdutoVirtual(int identification, String name, double value, String description, String brand, int categorie, double fileSize, String fileType, Categoria categoriee) {
        Produto produto = new ProdutoFisico(identification, name, value, description, brand, categorie, fileSize, fileType, categoriee);
        listaProdutos.add(produto);
    }
}