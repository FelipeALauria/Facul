package com.mycompany.commercetechgear;

import java.util.Scanner;

/**
 * Representa um produto físico na loja.
 */
public class ProdutoFisico extends Produto {
    private double peso;
    private String dimensoes;
    
    Scanner sc = new Scanner(System.in);
    
    /**
     * Constrói um novo produto físico.
     * 
     * @param id o ID do produto
     * @param nome o nome do produto
     * @param preco o preço do produto
     * @param descricao a descrição do produto
     * @param marca a marca do produto
     * @param categoria a categoria do produto
     * @param peso o peso do produto
     * @param dimensoes as dimensões do produto
     * @param categoriaa a categoria à qual o produto pertence
     */
    public ProdutoFisico(int id, String nome, double preco, String descricao, String marca, int categoria, double peso, String dimensoes, Categoria categoriaa) {
        super(id, nome, preco, descricao, marca, categoria, categoriaa);
        this.peso = peso;
        this.dimensoes = dimensoes;
    }

    public double getPeso() {
        return peso;
    }

    public String getDimensoes() {
        return dimensoes;
    }
    
    /**
     * Calcula o frete para a entrega de itens físicos.
     * 
     * @param itens o número de itens para entrega
     */
    public void calcularFretei(int itens) {
        System.out.println("Digite o seu endereço:\n");
        String endereco = sc.nextLine();        
        double valor  = 1;
        
        valor += valor * itens;
        
        System.out.println("Frete para a entrega de " + itens + " item(ns) para o endereço " + endereco + " tem valor de: " + valor + " reais!");
    } 
}